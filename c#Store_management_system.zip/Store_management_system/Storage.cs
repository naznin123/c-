﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Store_manage
{
    public partial class Storage : MetroFramework.Forms.MetroForm
    {
        public Storage()
        {

            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source = (localdb)\MSSQLLocalDB;Initial Catalog = StoreMS; Integrated Security = True");

            // con.Open();
            //string CName = comboBox1.Text;
            //DataTable dt = new DataTable();
            //int catId = (from DataRow dr in dt.Rows where (string)dr["CategoryName"] == CName select(int)dr["CategoryId"]).FirstOrDefault();

            //int catId = (comboBox1.SelectedIndex) + 1;

            con.Open();
            string query = "INSERT INTO Product VALUES ('" + textBox1.Text + "','" + Int32.Parse(textBox2.Text) + "', '" + Int32.Parse(txtCategory.Text) + "','" + Int32.Parse(textBox5.Text) + "')";
            //string query = "INSERT INTO Product VALUES ('5','Test3','100','1','12')";

            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommand cmd = new SqlCommand(query, con);

            //sda.SelectCommand.ExecuteNonQuery();
            cmd.ExecuteNonQuery();

            textBox1.Clear();
            textBox2.Clear();
            textBox5.Clear();
            textBox4.Clear();

            con.Close();
            MessageBox.Show("Added !");
            this.loadProduct();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source = (localdb)\MSSQLLocalDB;Initial Catalog = StoreMS; Integrated Security = True");

            con.Open();
            string query = "UPDATE Product SET Product_Name = '" + textBox1.Text + "' WHERE ProductId = '" + textBox4.Text + "' ";
            string query1 = "UPDATE Product SET Price = '" + textBox2.Text + "' WHERE ProductId = '" + textBox4.Text + "' ";
            string query2 = "UPDATE Product SET Quantity = '" + textBox5.Text + "' WHERE ProductId = '" + textBox4.Text + "' ";
            string query3 = "UPDATE Product SET Category = '" + txtCategory.Text + "' WHERE ProductId = '" + textBox4.Text + "' ";

            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlDataAdapter sda1 = new SqlDataAdapter(query1, con);
            SqlDataAdapter sda2 = new SqlDataAdapter(query2, con);
            SqlDataAdapter sda3 = new SqlDataAdapter(query3, con);


            sda.SelectCommand.ExecuteNonQuery();
            sda1.SelectCommand.ExecuteNonQuery();
            sda2.SelectCommand.ExecuteNonQuery();
            sda3.SelectCommand.ExecuteNonQuery();
            this.loadProduct();
            con.Close();
            MessageBox.Show("Updated !");

        }

        //private void button2_Click(object sender, EventArgs e)
        //{
        //    SqlConnection con = new SqlConnection(@"Data Source = (localdb)\MSSQLLocalDB;Initial Catalog = StoreMS; Integrated Security = True");

        //    con.Open();
        //    string query = "DELETE FROM Product WHERE ProductId='" + textBox4.Text + "'";
        //    SqlDataAdapter sda = new SqlDataAdapter(query, con);
        //    sda.SelectCommand.ExecuteNonQuery();

        //    textBox1.Clear();
        //    textBox2.Clear();
        //    textBox5.Clear();
        //    textBox4.Clear();

        //    con.Close();
        //    MessageBox.Show("Deleted !");
        //}


        //private void AddPro_Load(object sender, EventArgs e)
        //{
        //    if (((Form)this.MdiParent).Controls["label1"].Text != "Admin")
        //    {
        //        button1.Enabled = false;
        //        button2.Enabled = false;
        //        button3.Enabled = false;
        //    }
        //    fill();
        //}

        //private void fill()
        //{
        //    string Error = "";
        //    DBProduct Obj = new DBProduct();
        //    DataTable table = Obj.getAllCategory(ref Error);

        //    comboBox1.DataSource = table;
        //    comboBox1.DisplayMember = "CategoryName";
        //    comboBox1.ValueMember = "CategoryId";
        //}

        //private void button4_Click_1(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        con.Open();
        //        string query = "select * from AllProduct";
        //        SqlDataAdapter sda = new SqlDataAdapter(query, con);
        //        DataTable dt = new DataTable();
        //        sda.Fill(dt);
        //        dataGridView1.DataSource = dt;
        //        con.Close();
        //    }
        //    catch(Exception e)
        //    {
        //        e.Message;
        //    }

        //}

        private void button5_Click(object sender, EventArgs e)
        {
            this.loadProduct();
        }

        public void loadProduct()
        {
            SqlConnection con = null;
            try
            {
                con = new SqlConnection(@"Data Source = (localdb)\MSSQLLocalDB;Initial Catalog = StoreMS; Integrated Security = True");
                con.Open();
                string query = "select * from Product";
                if (!string.IsNullOrEmpty(txtSearch.Text))
                {
                    query = "select * from Product where Product_Name like '%" + txtSearch.Text + "%'";
                }
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                if (ds.Tables.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    dataGridView1.DataSource = dt;

                }
                con.Close();

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

        }

        public void loadProduct(int id)
        {
            SqlConnection con = null;
            try
            {
                con = new SqlConnection(@"Data Source = (localdb)\MSSQLLocalDB;Initial Catalog =StoreMS; Integrated Security = True");
                con.Open();
                string query = "select * from Product where ProductId=" + id;

                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                if (ds.Tables.Count > 0)
                {
                    DataTable dt = ds.Tables[0];
                    if (dt.Rows.Count == 1)
                    {
                        textBox1.Text = dt.Rows[0][1].ToString();
                        textBox2.Text = dt.Rows[0][2].ToString();
                        textBox4.Text = dt.Rows[0][0].ToString();
                        txtCategory.Text = dt.Rows[0][3].ToString();
                        textBox5.Text = dt.Rows[0][4].ToString();
                        textBox4.ReadOnly = true;
                    }

                }


            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }

        }


        public void DeleteProduct(int id)
        {
            SqlConnection con = null;
            try
            {
                con = new SqlConnection(@"Data Source = (localdb)\MSSQLLocalDB;Initial Catalog = StoreMS; Integrated Security = True");
                con.Open();
                string query = "DELETE FROM Product WHERE ProductId = " + id;

                SqlCommand cmd = new SqlCommand(query, con);
                int i = cmd.ExecuteNonQuery();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                //DataSet ds = new DataSet();
                // sda.Fill(ds);
                MessageBox.Show(i + "Row deleted");

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            finally
            {
                if (con != null)
                {
                    con.Close();
                }
            }

        }


        private void Storage_Load(object sender, EventArgs e)
        {
            this.loadProduct();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int id = Int32.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                this.loadProduct(id);
                //MessageBox.Show(id+"");

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int id = Int32.Parse(textBox4.Text);
            this.DeleteProduct(id);
            this.loadProduct();

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            textBox4.Text = "Auto Generated";
            textBox5.Text = "";
            textBox2.Text = "";
            textBox1.Text = "";
            txtCategory.Text = "";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            this.loadProduct();
        }
    }
}

