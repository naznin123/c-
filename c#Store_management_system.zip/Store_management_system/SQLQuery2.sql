﻿INSERT INTO Product VALUES (4,'Test3',100,1,12);

 