﻿DELETE FROM Product
WHERE ProductId=5;